<?php
include 'ip.php';
header('Location: mobile.html');
exit
?>
